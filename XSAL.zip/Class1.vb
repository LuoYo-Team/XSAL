Imports System.Net.Http.

Public Class XSAL

    Public Function GetCodePair(EndPoint As String, ClientId As String, Optional Scope As String = Nothing)


    End Function


End Class
